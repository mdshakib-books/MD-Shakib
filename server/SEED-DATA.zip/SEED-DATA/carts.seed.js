import Cart from "../src/models/cart.model.js";

export const seedCarts = async (users, books) => {
    console.log("Seeding Carts...");

    // Give Bob Wilson a cart with 2 items
    const bobCart = await Cart.create({
        user: users[2]._id,
        items: [
            {
                bookId: books[0]._id, // The Silent Patient
                title: books[0].title,
                price: books[0].price,
                imageUrl: books[0].imageUrl,
                quantity: 1,
            },
            {
                bookId: books[1]._id, // Atomic Habits
                title: books[1].title,
                price: books[1].price,
                imageUrl: books[1].imageUrl,
                quantity: 2,
            },
        ],
        totalPrice: books[0].price + books[1].price * 2,
    });

    console.log(`✅ Seeded 1 Cart for Bob Wilson.`);
    return [bobCart];
};
